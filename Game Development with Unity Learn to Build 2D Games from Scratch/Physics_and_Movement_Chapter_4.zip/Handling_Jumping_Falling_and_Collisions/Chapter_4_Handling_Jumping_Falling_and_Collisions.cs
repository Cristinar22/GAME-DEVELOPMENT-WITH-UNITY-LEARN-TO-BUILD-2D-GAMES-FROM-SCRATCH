
// Collision handling code is explained in the chapter, no direct code provided.
