
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    private Rigidbody2D rb;
    public float speed = 5f;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    void Update()
    {
        // Get the player's horizontal input
        float horizontalInput = Input.GetAxis("Horizontal");

        // Apply force to the player based on input
        rb.velocity = new Vector2(horizontalInput * speed, rb.velocity.y);
    }
}
