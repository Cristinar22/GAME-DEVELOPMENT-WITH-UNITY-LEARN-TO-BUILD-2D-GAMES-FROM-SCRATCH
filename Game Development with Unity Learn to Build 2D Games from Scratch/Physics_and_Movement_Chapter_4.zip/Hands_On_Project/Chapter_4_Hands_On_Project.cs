// Setup script for hands-on project. Please refer to the specific code implementation in earlier sections.
