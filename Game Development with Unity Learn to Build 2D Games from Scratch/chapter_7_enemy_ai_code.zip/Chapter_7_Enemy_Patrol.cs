using UnityEngine;

public class EnemyPatrol : MonoBehaviour
{
    public Transform pointA;  // Patrol point A
    public Transform pointB;  // Patrol point B
    public float speed = 2f;  // Speed at which the enemy moves

    private bool movingToPointB = true;

    void Update()
    {
        Patrol();
    }

    void Patrol()
    {
        // Move the enemy towards the current patrol point
        if (movingToPointB)
        {
            transform.position = Vector2.MoveTowards(transform.position, pointB.position, speed * Time.deltaTime);
            if (Vector2.Distance(transform.position, pointB.position) < 0.1f)
            {
                movingToPointB = false;  // Switch direction
            }
        }
        else
        {
            transform.position = Vector2.MoveTowards(transform.position, pointA.position, speed * Time.deltaTime);
            if (Vector2.Distance(transform.position, pointA.position) < 0.1f)
            {
                movingToPointB = true;  // Switch direction
            }
        }
    }
}
