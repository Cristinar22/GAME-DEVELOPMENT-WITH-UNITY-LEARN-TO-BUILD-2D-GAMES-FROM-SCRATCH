using UnityEngine;

public class EnemyChase : MonoBehaviour
{
    public Transform player;  // Reference to the player
    public float chaseRange = 5f;  // Distance within which the enemy will start chasing
    public float speed = 3f;  // Speed at which the enemy chases the player
    private bool isChasing = false;

    void Update()
    {
        if (Vector2.Distance(transform.position, player.position) < chaseRange)
        {
            isChasing = true;
        }
        else
        {
            isChasing = false;
        }

        if (isChasing)
        {
            ChasePlayer();
        }
    }

    void ChasePlayer()
    {
        // Move the enemy towards the player
        transform.position = Vector2.MoveTowards(transform.position, player.position, speed * Time.deltaTime);
    }
}
