using UnityEngine;

public class EnemyAttack : MonoBehaviour
{
    public float attackRange = 1f;  // Range within which the enemy will attack
    public int attackDamage = 10;  // Damage dealt to the player

    void Update()
    {
        if (Vector2.Distance(transform.position, player.position) < attackRange)
        {
            AttackPlayer();
        }
    }

    void AttackPlayer()
    {
        // Code to deal damage to the player
        Debug.Log("Player is attacked! Damage: " + attackDamage);
    }
}
