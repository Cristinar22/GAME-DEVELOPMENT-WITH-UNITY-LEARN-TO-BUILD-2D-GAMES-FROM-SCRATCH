
// NullReferenceException handling example
public GameObject player;

void Start()
{
    if (player == null)
    {
        Debug.LogError("Player not assigned!");
    }
}
