
Debug.LogWarning("Low health warning!");
Debug.LogError("Game over! Player health is zero.");
