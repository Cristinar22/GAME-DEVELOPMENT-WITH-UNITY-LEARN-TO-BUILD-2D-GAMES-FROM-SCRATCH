
if (score > highScore)
{
    Debug.Log("New high score: " + score);
}
