
// Profiler setup code can be added in Unity's editor; no code is required here.
