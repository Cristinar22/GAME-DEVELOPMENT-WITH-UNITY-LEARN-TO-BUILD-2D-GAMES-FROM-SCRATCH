
// Example of object pooling to avoid memory leaks
public class ObjectPooler
{
    private List<GameObject> pool = new List<GameObject>();

    public GameObject GetObject()
    {
        if (pool.Count > 0)
        {
            return pool[0];
        }
        else
        {
            return CreateNewObject();
        }
    }

    private GameObject CreateNewObject()
    {
        return new GameObject(); // Object creation logic
    }
}
