
// IndexOutOfRangeException handling example
if (index >= 0 && index < myArray.Length)
{
    Debug.Log("Array element: " + myArray[index]);
}
else
{
    Debug.LogError("Index out of range");
}
