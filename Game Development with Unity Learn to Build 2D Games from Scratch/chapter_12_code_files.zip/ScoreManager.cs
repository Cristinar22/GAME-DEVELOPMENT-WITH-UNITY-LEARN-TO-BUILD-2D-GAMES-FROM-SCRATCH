
using UnityEngine;

public class ScoreManager : MonoBehaviour
{
    public int currentScore = 0;

    public void AddScore(int points)
    {
        currentScore += points;
        PlayerPrefs.SetInt("PlayerScore", currentScore);
        PlayerPrefs.Save();
    }

    public void LoadScore()
    {
        if (PlayerPrefs.HasKey("PlayerScore"))
        {
            currentScore = PlayerPrefs.GetInt("PlayerScore");
        }
    }
}
