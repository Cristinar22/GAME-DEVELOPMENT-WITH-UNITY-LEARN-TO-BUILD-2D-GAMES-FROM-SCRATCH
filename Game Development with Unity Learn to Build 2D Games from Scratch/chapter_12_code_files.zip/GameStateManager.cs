
using UnityEngine;

public class GameStateManager : MonoBehaviour
{
    public void SaveGameState(GameState gameState)
    {
        string json = JsonUtility.ToJson(gameState);
        PlayerPrefs.SetString("GameState", json);
        PlayerPrefs.Save();
    }

    public GameState LoadGameState()
    {
        string json = PlayerPrefs.GetString("GameState", "");
        if (string.IsNullOrEmpty(json))
        {
            return new GameState();  // Return default game state
        }
        return JsonUtility.FromJson<GameState>(json);
    }
}
