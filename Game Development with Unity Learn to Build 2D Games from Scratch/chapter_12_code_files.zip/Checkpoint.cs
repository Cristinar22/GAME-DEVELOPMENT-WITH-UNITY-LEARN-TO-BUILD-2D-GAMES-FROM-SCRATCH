
using UnityEngine;

public class Checkpoint : MonoBehaviour
{
    public void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            // Save the checkpoint data (level, position, etc.)
            GameState gameState = new GameState();
            gameState.level = currentLevel;
            gameState.timePlayed = timePlayed;

            // Save this checkpoint
            gameStateManager.SaveGameState(gameState);
        }
    }
}
