
using UnityEngine;

public class AutoSaveSystem : MonoBehaviour
{
    public void SaveProgress()
    {
        GameState gameState = new GameState();
        gameState.level = playerProgress.currentLevel;
        gameState.score = scoreManager.currentScore;

        // Auto-save every time the player completes a level
        gameStateManager.SaveGameState(gameState);
    }
}
