
using UnityEngine;

public class PreferencesManager : MonoBehaviour
{
    public void SavePreferences(bool isMuted, float volume)
    {
        PlayerPrefs.SetInt("IsMuted", isMuted ? 1 : 0);
        PlayerPrefs.SetFloat("Volume", volume);
        PlayerPrefs.Save();
    }

    public void LoadPreferences()
    {
        bool isMuted = PlayerPrefs.GetInt("IsMuted", 0) == 1;
        float volume = PlayerPrefs.GetFloat("Volume", 1.0f);

        // Apply these preferences to your game settings
    }
}
