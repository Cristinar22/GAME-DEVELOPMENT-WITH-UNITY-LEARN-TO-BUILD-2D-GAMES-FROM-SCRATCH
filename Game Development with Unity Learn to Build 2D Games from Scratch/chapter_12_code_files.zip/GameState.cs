
using UnityEngine;

[System.Serializable]
public class GameState
{
    public int level;
    public int score;
    public float timePlayed;
}
