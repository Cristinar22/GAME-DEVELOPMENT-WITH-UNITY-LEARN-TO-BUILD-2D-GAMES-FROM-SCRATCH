
using UnityEngine;

public class PlayerProgress : MonoBehaviour
{
    public int currentLevel = 1;
    public int maxLevel = 3;  // Set the number of levels in your game

    void Start()
    {
        LoadProgress();
    }

    public void UnlockNextLevel()
    {
        if (currentLevel < maxLevel)
        {
            currentLevel++;
            SaveProgress();
        }
    }

    public void SaveProgress()
    {
        PlayerPrefs.SetInt("CurrentLevel", currentLevel);
        PlayerPrefs.Save();
    }

    public void LoadProgress()
    {
        if (PlayerPrefs.HasKey("CurrentLevel"))
        {
            currentLevel = PlayerPrefs.GetInt("CurrentLevel");
        }
    }
}
