using UnityEngine;

public class SpeedBoost : MonoBehaviour
{
    public float speedMultiplier = 2f;  // Multiplier for speed
    public float duration = 5f;  // Duration of the boost

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            PlayerMovement playerMovement = other.GetComponent<PlayerMovement>();
            if (playerMovement != null)
            {
                StartCoroutine(playerMovement.ApplySpeedBoost(speedMultiplier, duration));
                Destroy(gameObject);  // Destroy the power-up after it's collected
            }
        }
    }
}
