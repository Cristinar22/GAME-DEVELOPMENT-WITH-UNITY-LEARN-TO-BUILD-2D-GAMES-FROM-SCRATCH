using UnityEngine;
using System.Collections;

public class PlayerMovement : MonoBehaviour
{
    public float moveSpeed = 5f;

    public IEnumerator ApplySpeedBoost(float multiplier, float time)
    {
        moveSpeed *= multiplier;  // Increase speed
        yield return new WaitForSeconds(time);
        moveSpeed /= multiplier;  // Reset speed after duration
    }
}
