using UnityEngine;

public class PlayerHealth : MonoBehaviour
{
    public int maxHealth = 100;
    private int currentHealth;

    void Start()
    {
        currentHealth = maxHealth;
    }

    public void RestoreHealth(int amount)
    {
        currentHealth = Mathf.Min(currentHealth + amount, maxHealth);  // Restore health without exceeding maxHealth
        Debug.Log("Health restored! Current health: " + currentHealth);
    }

    public void TakeDamage(int damage)
    {
        currentHealth -= damage;
        if (currentHealth <= 0)
        {
            currentHealth = 0;
            // Trigger game over or restart level
            GameOver();
        }
    }

    void GameOver()
    {
        Debug.Log("Game Over!");
        // Here, you can load the game over scene or show a game over UI screen
    }
}
