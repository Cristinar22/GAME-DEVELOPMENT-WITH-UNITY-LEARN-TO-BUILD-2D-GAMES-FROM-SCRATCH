using UnityEngine;

public class Enemy : MonoBehaviour
{
    public float speed = 2f;  // Enemy's base speed
    public float speedMultiplier = 1.1f;

    void Start()
    {
        speed *= speedMultiplier;  // Increase speed as the game progresses
    }
}
