using UnityEngine;

public class HealthPowerUp : MonoBehaviour
{
    public int healthAmount = 25;  // The amount of health the power-up will restore

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            // Get the player's health and add the healthAmount
            PlayerHealth playerHealth = other.GetComponent<PlayerHealth>();
            if (playerHealth != null)
            {
                playerHealth.RestoreHealth(healthAmount);
                Destroy(gameObject);  // Destroy the power-up after it's collected
            }
        }
    }
}
