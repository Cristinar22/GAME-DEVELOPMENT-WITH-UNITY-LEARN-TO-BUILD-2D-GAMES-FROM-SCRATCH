using UnityEngine;

public class PlayerUpgrades : MonoBehaviour
{
    public int playerHealth = 100;
    public int coins = 0;

    public void UpgradeHealth()
    {
        if (coins >= 10)
        {
            playerHealth += 50;
            coins -= 10;
            Debug.Log("Health upgraded! Current Health: " + playerHealth);
        }
    }
}
