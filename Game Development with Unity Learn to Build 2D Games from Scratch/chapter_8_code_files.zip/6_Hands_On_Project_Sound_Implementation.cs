// Hands-on project code for implementing sound effects and background music
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public AudioSource jumpAudioSource;
    public AudioClip jumpSound;
    public AudioSource collectAudioSource;
    public AudioClip collectSound;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            Jump();
        }
    }

    void Jump()
    {
        jumpAudioSource.PlayOneShot(jumpSound);  // Play the jump sound
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Coin"))
        {
            collectAudioSource.PlayOneShot(collectSound);  // Play the coin collection sound
            Destroy(collision.gameObject);  // Destroy the coin
        }
    }
}
