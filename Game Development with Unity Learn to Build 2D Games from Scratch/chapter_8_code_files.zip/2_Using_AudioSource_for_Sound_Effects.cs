// Code for attaching and using AudioSource for player actions like jumping
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public AudioSource jumpAudioSource;  // The AudioSource for the jump sound
    public AudioClip jumpSound;  // The sound to play when jumping

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            Jump();
        }
    }

    void Jump()
    {
        // Play the jump sound
        jumpAudioSource.PlayOneShot(jumpSound);
    }
}
