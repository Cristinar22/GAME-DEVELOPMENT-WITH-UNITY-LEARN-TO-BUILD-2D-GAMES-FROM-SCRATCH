// Code for using 3D sounds in Unity to simulate real-world sounds
using UnityEngine;

public class Enemy : MonoBehaviour
{
    public AudioSource explosionSound;
    
    void Start()
    {
        explosionSound.spatialBlend = 1.0f; // 3D Sound
        explosionSound.Play();
    }
}
