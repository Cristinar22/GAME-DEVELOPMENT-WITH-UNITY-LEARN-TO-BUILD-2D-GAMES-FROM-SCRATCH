// Code for adding looping background music in Unity
using UnityEngine;

public class MusicManager : MonoBehaviour
{
    public AudioSource backgroundMusic;  // The AudioSource that plays the music

    void Start()
    {
        // Start the background music
        backgroundMusic.Play();
    }

    public void StopMusic()
    {
        backgroundMusic.Stop();  // Stop the background music
    }
}
