// Code for creating ambient soundscapes in Unity
using UnityEngine;

public class AmbientSound : MonoBehaviour
{
    public AudioSource ambientSound;  // Ambient sound for the game world

    void Start()
    {
        ambientSound.loop = true;  // Loop the ambient sound
        ambientSound.Play();
    }
}
