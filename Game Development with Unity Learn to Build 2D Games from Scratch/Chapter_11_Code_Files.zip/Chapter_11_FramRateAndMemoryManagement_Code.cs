using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public ParticleSystem jumpParticles;

    void Jump()
    {
        // Play particle effect when player jumps
        jumpParticles.Play();
    }
}