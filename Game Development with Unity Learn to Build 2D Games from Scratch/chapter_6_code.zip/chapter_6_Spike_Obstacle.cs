
using UnityEngine;

public class Spike : MonoBehaviour
{
    void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            // Code for damaging the player
            Debug.Log("Player hit the spikes!");
        }
    }
}
