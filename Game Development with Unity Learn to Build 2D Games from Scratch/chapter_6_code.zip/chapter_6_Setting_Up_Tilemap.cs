
using UnityEngine;

public class TilemapSetup : MonoBehaviour
{
    void Start()
    {
        // Tilemap setup code
    }
}
