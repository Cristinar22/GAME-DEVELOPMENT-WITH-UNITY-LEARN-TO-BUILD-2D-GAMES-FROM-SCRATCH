
using UnityEngine;

public class Collectible : MonoBehaviour
{
    void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            // Code for collecting the item (e.g., increase score)
            Destroy(gameObject);  // Remove the collectible from the scene
            Debug.Log("Item collected!");
        }
    }
}
