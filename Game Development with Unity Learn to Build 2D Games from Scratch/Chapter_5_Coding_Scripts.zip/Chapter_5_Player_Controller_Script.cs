using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public float speed = 5f;  // Movement speed of the player

    void Update()
    {
        // Get horizontal input (Arrow keys or A/D)
        float horizontal = Input.GetAxis("Horizontal");

        // Move the player horizontally
        transform.Translate(Vector2.right * horizontal * speed * Time.deltaTime);
    }
}
