int score = 0;  // Declare an integer variable named 'score' and initialize it to 0.
float speed = 5.5f;  // Declare a float variable 'speed'.
string playerName = "Mario";  // Declare a string variable 'playerName' with the value "Mario".
