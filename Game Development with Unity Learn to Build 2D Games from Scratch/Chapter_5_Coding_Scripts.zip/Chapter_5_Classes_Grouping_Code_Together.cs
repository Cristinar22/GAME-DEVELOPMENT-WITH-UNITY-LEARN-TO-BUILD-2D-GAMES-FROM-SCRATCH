public class Player {
    // Variables
    public string name;
    public int health;

    // Function to display player info
    public void DisplayInfo() {
        Console.WriteLine("Player Name: " + name);
        Console.WriteLine("Health: " + health);
    }
}
