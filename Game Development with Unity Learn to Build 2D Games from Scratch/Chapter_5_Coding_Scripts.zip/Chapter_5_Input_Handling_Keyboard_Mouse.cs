void Update() {
    if (Input.GetKey(KeyCode.LeftArrow)) {
        transform.Translate(Vector2.left * speed * Time.deltaTime);  // Move left.
    }
    if (Input.GetKey(KeyCode.RightArrow)) {
        transform.Translate(Vector2.right * speed * Time.deltaTime);  // Move right.
    }
}
