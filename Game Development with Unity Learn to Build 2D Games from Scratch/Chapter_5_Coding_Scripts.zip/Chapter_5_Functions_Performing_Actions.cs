void PrintMessage() {
    Console.WriteLine("Hello, World!");  // Prints a message to the console.
}

int AddNumbers(int a, int b) {
    return a + b;  // Returns the sum of a and b.
}
