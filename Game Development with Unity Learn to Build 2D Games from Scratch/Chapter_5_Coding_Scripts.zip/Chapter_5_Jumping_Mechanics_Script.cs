public class PlayerController : MonoBehaviour
{
    public float speed = 5f;
    public float jumpForce = 10f;  // The force of the jump
    private bool isGrounded;

    private Rigidbody2D rb;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    void Update()
    {
        // Get horizontal input (Arrow keys or A/D)
        float horizontal = Input.GetAxis("Horizontal");

        // Move the player horizontally
        transform.Translate(Vector2.right * horizontal * speed * Time.deltaTime);

        // Jumping logic
        if (isGrounded && Input.GetKeyDown(KeyCode.Space))
        {
            rb.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);
        }
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.contacts.Length > 0)
        {
            isGrounded = true;  // Player is on the ground
        }
    }

    void OnCollisionExit2D(Collision2D collision)
    {
        isGrounded = false;  // Player is off the ground
    }
}
